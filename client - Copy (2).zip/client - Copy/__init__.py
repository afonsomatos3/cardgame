"""WarMasterMind Thin Client Package."""
