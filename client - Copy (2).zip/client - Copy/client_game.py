"""WarMasterMind Thin Client - Multiplayer game client."""

import pygame
import sys
import os
import json
from pathlib import Path

from network import NetworkClient


# Screen settings
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60

# Colors
BG_COLOR = (30, 35, 40)
WHITE = (255, 255, 255)
GRAY = (150, 150, 150)
RED = (255, 100, 100)
BLUE = (100, 150, 255)
GREEN = (100, 200, 100)

# Game states
STATE_LOGIN = "login"
STATE_LOBBY = "lobby"
STATE_MATCHMAKING = "matchmaking"
STATE_GAME = "game"
STATE_GAME_OVER = "game_over"


class ThinClient:
    """Thin client for WarMasterMind multiplayer."""

    def __init__(self, server_url: str = "ws://localhost:8765"):
        pygame.init()
        pygame.display.set_caption("WarMasterMind - Online")

        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        self.clock = pygame.time.Clock()
        self.running = True

        self.screen_width = SCREEN_WIDTH
        self.screen_height = SCREEN_HEIGHT

        # Fonts
        self.title_font = pygame.font.Font(None, 72)
        self.font = pygame.font.Font(None, 36)
        self.small_font = pygame.font.Font(None, 24)

        # Network
        self.network = NetworkClient(server_url)
        self.network.on_game_state = self._on_game_state
        self.network.on_match_found = self._on_match_found
        self.network.on_action_result = self._on_action_result
        self.network.on_error = self._on_error

        # State
        self.state = STATE_LOGIN
        self.game_state = None
        self.match_info = None
        self.error_message = None
        self.error_timer = 0

        # Login state
        self.username_input = ""
        self.password_input = ""
        self.active_input = "username"
        self.is_registering = False

        # Available cards (received from server)
        self.available_cards = {}

        # UI state
        self.selected_card = None
        self.selected_location = None
        self.hovered_location = None

        # Card image cache
        self._card_cache = {}

        # Location layout
        self.locations = {}
        self._setup_locations()

        # Try to load saved token
        self._load_token()

    def _setup_locations(self):
        """Setup battlefield location rectangles."""
        center_x = self.screen_width // 2
        center_y = self.screen_height // 2

        zone_width = 150
        zone_height = 80
        h_spacing = 180
        v_spacing = 100

        layout = {
            "Camp": (0, 0), "Forest": (0, 1),
            "Gate": (1, 0), "Walls": (1, 1), "Sewers": (1, 2),
            "Courtyard": (2, 0), "Keep": (2, 1),
        }

        row_ys = [
            center_y + v_spacing,
            center_y,
            center_y - v_spacing,
        ]

        for name, (row, pos) in layout.items():
            num_in_row = 2 if row in [0, 2] else 3
            if num_in_row == 2:
                x = center_x + (pos - 0.5) * h_spacing * 1.2
            else:
                x = center_x + (pos - 1) * h_spacing

            self.locations[name] = pygame.Rect(
                int(x - zone_width // 2),
                int(row_ys[row] - zone_height // 2),
                zone_width, zone_height
            )

    def _load_token(self):
        """Load saved auth token."""
        token_file = Path("token.json")
        if token_file.exists():
            try:
                data = json.loads(token_file.read_text())
                self.network.token = data.get("token")
            except:
                pass

    def _save_token(self):
        """Save auth token."""
        if self.network.token:
            Path("token.json").write_text(json.dumps({"token": self.network.token}))

    def _on_game_state(self, state: dict):
        """Handle received game state."""
        self.game_state = state

    def _on_match_found(self, data: dict):
        """Handle match found."""
        self.match_info = data
        self.state = STATE_GAME

    def _on_action_result(self, data: dict):
        """Handle action result."""
        if data.get("winner"):
            self.state = STATE_GAME_OVER
            self.winner = data["winner"]

    def _on_error(self, error: str):
        """Handle error."""
        self.error_message = error
        self.error_timer = 3.0

    def connect(self) -> bool:
        """Connect to server."""
        if self.network.connect():
            # Try to auth with saved token
            if self.network.token:
                self.network.auth_with_token(self.network.token)
            return True
        return False

    def handle_events(self):
        """Handle pygame events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.VIDEORESIZE:
                self.screen_width = event.w
                self.screen_height = event.h
                self.screen = pygame.display.set_mode((event.w, event.h), pygame.RESIZABLE)
                self._setup_locations()

            elif event.type == pygame.MOUSEMOTION:
                self._handle_mouse_motion(event.pos)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self._handle_click(event.pos)

            elif event.type == pygame.KEYDOWN:
                self._handle_key(event)

    def _handle_mouse_motion(self, pos):
        """Handle mouse movement."""
        self.hovered_location = None
        if self.state == STATE_GAME:
            for name, rect in self.locations.items():
                if rect.collidepoint(pos):
                    self.hovered_location = name
                    break

    def _handle_click(self, pos):
        """Handle mouse click."""
        if self.state == STATE_LOGIN:
            self._handle_login_click(pos)
        elif self.state == STATE_LOBBY:
            self._handle_lobby_click(pos)
        elif self.state == STATE_GAME:
            self._handle_game_click(pos)
        elif self.state == STATE_GAME_OVER:
            # Return to lobby
            self.state = STATE_LOBBY
            self.game_state = None
            self.match_info = None

    def _handle_login_click(self, pos):
        """Handle clicks on login screen."""
        # Username field
        username_rect = pygame.Rect(self.screen_width // 2 - 150, 280, 300, 40)
        password_rect = pygame.Rect(self.screen_width // 2 - 150, 340, 300, 40)
        submit_rect = pygame.Rect(self.screen_width // 2 - 100, 420, 200, 50)
        toggle_rect = pygame.Rect(self.screen_width // 2 - 100, 490, 200, 30)

        if username_rect.collidepoint(pos):
            self.active_input = "username"
        elif password_rect.collidepoint(pos):
            self.active_input = "password"
        elif submit_rect.collidepoint(pos):
            if self.username_input and self.password_input:
                if self.is_registering:
                    self.network.register(self.username_input, self.password_input)
                else:
                    self.network.login(self.username_input, self.password_input)
        elif toggle_rect.collidepoint(pos):
            self.is_registering = not self.is_registering

    def _handle_lobby_click(self, pos):
        """Handle clicks on lobby screen."""
        find_match_rect = pygame.Rect(self.screen_width // 2 - 100, 300, 200, 50)
        if find_match_rect.collidepoint(pos):
            self.network.find_match()
            self.state = STATE_MATCHMAKING

    def _handle_game_click(self, pos):
        """Handle clicks during game."""
        if not self.game_state:
            return

        # Check location clicks
        for name, rect in self.locations.items():
            if rect.collidepoint(pos):
                self._on_location_click(name)
                return

        # Check end turn button
        end_turn_rect = pygame.Rect(self.screen_width - 150, 20, 130, 40)
        if end_turn_rect.collidepoint(pos):
            if self.game_state.get("is_your_turn"):
                self.network.end_turn()

        # Check hand card clicks
        self._handle_hand_click(pos)

        # Check deck click
        deck_rect = pygame.Rect(self.screen_width - 120, self.screen_height - 180, 100, 140)
        if deck_rect.collidepoint(pos):
            if self.game_state.get("is_your_turn") and self.game_state.get("can_draw"):
                # Show draw menu or auto-draw first card
                deck_cards = self.game_state.get("deck_cards", [])
                if deck_cards:
                    self.network.draw_card(deck_cards[0])

    def _on_location_click(self, location: str):
        """Handle clicking on a battlefield location."""
        if not self.game_state or not self.game_state.get("is_your_turn"):
            return

        # If we have a selected card from hand, place it
        if self.selected_card:
            self.network.place_card(self.selected_card, location)
            self.selected_card = None

    def _handle_hand_click(self, pos):
        """Handle clicking on cards in hand."""
        if not self.game_state:
            return

        hand = self.game_state.get("hand", [])
        if not hand:
            return

        # Hand is at bottom of screen
        hand_y = self.screen_height - 160
        card_width = 80
        card_height = 112
        total_width = len(hand) * (card_width + 10)
        start_x = (self.screen_width - total_width) // 2

        for i, card in enumerate(hand):
            card_x = start_x + i * (card_width + 10)
            card_rect = pygame.Rect(card_x, hand_y, card_width, card_height)
            if card_rect.collidepoint(pos):
                self.selected_card = card.get("card_id")
                return

    def _handle_key(self, event):
        """Handle key press."""
        if self.state == STATE_LOGIN:
            if event.key == pygame.K_TAB:
                self.active_input = "password" if self.active_input == "username" else "username"
            elif event.key == pygame.K_RETURN:
                if self.username_input and self.password_input:
                    if self.is_registering:
                        self.network.register(self.username_input, self.password_input)
                    else:
                        self.network.login(self.username_input, self.password_input)
            elif event.key == pygame.K_BACKSPACE:
                if self.active_input == "username":
                    self.username_input = self.username_input[:-1]
                else:
                    self.password_input = self.password_input[:-1]
            else:
                char = event.unicode
                if char.isprintable() and len(char) == 1:
                    if self.active_input == "username" and len(self.username_input) < 20:
                        self.username_input += char
                    elif self.active_input == "password" and len(self.password_input) < 30:
                        self.password_input += char

        elif event.key == pygame.K_ESCAPE:
            if self.state == STATE_MATCHMAKING:
                self.network.cancel_match()
                self.state = STATE_LOBBY
            elif self.state == STATE_GAME:
                self.selected_card = None

    def update(self, dt: float):
        """Update game state."""
        # Process network messages
        self.network.process_messages()

        # Check if authenticated
        if self.network.authenticated and self.state == STATE_LOGIN:
            self._save_token()
            self.state = STATE_LOBBY
            self.network.get_cards()

        # Update error timer
        if self.error_timer > 0:
            self.error_timer -= dt
            if self.error_timer <= 0:
                self.error_message = None

    def draw(self):
        """Draw the game."""
        self.screen.fill(BG_COLOR)

        if self.state == STATE_LOGIN:
            self._draw_login()
        elif self.state == STATE_LOBBY:
            self._draw_lobby()
        elif self.state == STATE_MATCHMAKING:
            self._draw_matchmaking()
        elif self.state == STATE_GAME:
            self._draw_game()
        elif self.state == STATE_GAME_OVER:
            self._draw_game_over()

        # Draw error message
        if self.error_message:
            error_surf = self.font.render(self.error_message, True, RED)
            error_rect = error_surf.get_rect(center=(self.screen_width // 2, 50))
            pygame.draw.rect(self.screen, (50, 30, 30),
                           error_rect.inflate(20, 10), border_radius=5)
            self.screen.blit(error_surf, error_rect)

        # Draw connection status
        status = "Connected" if self.network.connected else "Disconnected"
        status_color = GREEN if self.network.connected else RED
        status_surf = self.small_font.render(status, True, status_color)
        self.screen.blit(status_surf, (10, 10))

        pygame.display.flip()

    def _draw_login(self):
        """Draw login screen."""
        # Title
        title = self.title_font.render("WarMasterMind", True, (255, 200, 100))
        title_rect = title.get_rect(center=(self.screen_width // 2, 120))
        self.screen.blit(title, title_rect)

        subtitle = self.small_font.render("Online Multiplayer", True, GRAY)
        sub_rect = subtitle.get_rect(center=(self.screen_width // 2, 170))
        self.screen.blit(subtitle, sub_rect)

        # Mode text
        mode = "Register New Account" if self.is_registering else "Login"
        mode_surf = self.font.render(mode, True, WHITE)
        mode_rect = mode_surf.get_rect(center=(self.screen_width // 2, 230))
        self.screen.blit(mode_surf, mode_rect)

        # Username field
        username_rect = pygame.Rect(self.screen_width // 2 - 150, 280, 300, 40)
        color = (100, 100, 150) if self.active_input == "username" else (70, 70, 80)
        pygame.draw.rect(self.screen, color, username_rect, border_radius=5)
        pygame.draw.rect(self.screen, WHITE if self.active_input == "username" else GRAY,
                        username_rect, 2, border_radius=5)

        username_label = self.small_font.render("Username:", True, GRAY)
        self.screen.blit(username_label, (username_rect.x, username_rect.y - 20))

        username_text = self.font.render(self.username_input, True, WHITE)
        self.screen.blit(username_text, (username_rect.x + 10, username_rect.y + 8))

        # Password field
        password_rect = pygame.Rect(self.screen_width // 2 - 150, 340, 300, 40)
        color = (100, 100, 150) if self.active_input == "password" else (70, 70, 80)
        pygame.draw.rect(self.screen, color, password_rect, border_radius=5)
        pygame.draw.rect(self.screen, WHITE if self.active_input == "password" else GRAY,
                        password_rect, 2, border_radius=5)

        password_label = self.small_font.render("Password:", True, GRAY)
        self.screen.blit(password_label, (password_rect.x, password_rect.y - 20))

        password_display = "*" * len(self.password_input)
        password_text = self.font.render(password_display, True, WHITE)
        self.screen.blit(password_text, (password_rect.x + 10, password_rect.y + 8))

        # Submit button
        submit_rect = pygame.Rect(self.screen_width // 2 - 100, 420, 200, 50)
        pygame.draw.rect(self.screen, (70, 130, 70), submit_rect, border_radius=8)
        submit_text = self.font.render("Register" if self.is_registering else "Login", True, WHITE)
        submit_text_rect = submit_text.get_rect(center=submit_rect.center)
        self.screen.blit(submit_text, submit_text_rect)

        # Toggle button
        toggle_rect = pygame.Rect(self.screen_width // 2 - 100, 490, 200, 30)
        toggle_text = "Already have account? Login" if self.is_registering else "Need account? Register"
        toggle_surf = self.small_font.render(toggle_text, True, BLUE)
        toggle_text_rect = toggle_surf.get_rect(center=toggle_rect.center)
        self.screen.blit(toggle_surf, toggle_text_rect)

    def _draw_lobby(self):
        """Draw lobby screen."""
        # Title
        title = self.title_font.render("Lobby", True, WHITE)
        title_rect = title.get_rect(center=(self.screen_width // 2, 100))
        self.screen.blit(title, title_rect)

        # Welcome message
        welcome = self.font.render(f"Welcome, {self.network.username}!", True, GREEN)
        welcome_rect = welcome.get_rect(center=(self.screen_width // 2, 180))
        self.screen.blit(welcome, welcome_rect)

        # Find match button
        find_match_rect = pygame.Rect(self.screen_width // 2 - 100, 300, 200, 50)
        pygame.draw.rect(self.screen, (70, 130, 70), find_match_rect, border_radius=8)
        find_text = self.font.render("Find Match", True, WHITE)
        find_text_rect = find_text.get_rect(center=find_match_rect.center)
        self.screen.blit(find_text, find_text_rect)

    def _draw_matchmaking(self):
        """Draw matchmaking screen."""
        title = self.title_font.render("Finding Match...", True, WHITE)
        title_rect = title.get_rect(center=(self.screen_width // 2, self.screen_height // 2 - 50))
        self.screen.blit(title, title_rect)

        hint = self.small_font.render("Press ESC to cancel", True, GRAY)
        hint_rect = hint.get_rect(center=(self.screen_width // 2, self.screen_height // 2 + 50))
        self.screen.blit(hint, hint_rect)

    def _draw_game(self):
        """Draw the game."""
        if not self.game_state:
            loading = self.font.render("Loading game...", True, WHITE)
            loading_rect = loading.get_rect(center=(self.screen_width // 2, self.screen_height // 2))
            self.screen.blit(loading, loading_rect)
            return

        # Draw battlefield
        self._draw_battlefield()

        # Draw hand
        self._draw_hand()

        # Draw turn info
        self._draw_turn_info()

        # Draw deck
        self._draw_deck()

    def _draw_battlefield(self):
        """Draw the battlefield locations."""
        for name, rect in self.locations.items():
            bf_data = self.game_state.get("battlefield", {}).get(name, {})

            # Determine color
            controller = bf_data.get("controller")
            if controller == "attacker":
                base_color = (150, 70, 70)
            elif controller == "defender":
                base_color = (70, 70, 150)
            else:
                base_color = (80, 80, 80)

            # Hover effect
            if name == self.hovered_location:
                base_color = tuple(min(c + 30, 255) for c in base_color)

            pygame.draw.rect(self.screen, base_color, rect, border_radius=8)
            pygame.draw.rect(self.screen, GRAY, rect, 2, border_radius=8)

            # Location name
            name_surf = self.small_font.render(name, True, WHITE)
            name_rect = name_surf.get_rect(centerx=rect.centerx, top=rect.top + 5)
            self.screen.blit(name_surf, name_rect)

            # Card counts
            own_count = len(bf_data.get("own_cards", []))
            enemy_count = bf_data.get("enemy_count")

            count_y = rect.top + 30
            if own_count > 0:
                own_surf = self.small_font.render(f"You: {own_count}", True, GREEN)
                self.screen.blit(own_surf, (rect.left + 5, count_y))

            if bf_data.get("can_see"):
                if enemy_count and enemy_count > 0:
                    enemy_surf = self.small_font.render(f"Enemy: {enemy_count}", True, RED)
                    self.screen.blit(enemy_surf, (rect.left + 5, count_y + 18))
            else:
                fog_surf = self.small_font.render("???", True, (100, 100, 100))
                self.screen.blit(fog_surf, (rect.left + 5, count_y + 18))

    def _draw_hand(self):
        """Draw cards in hand."""
        hand = self.game_state.get("hand", [])
        if not hand:
            return

        hand_y = self.screen_height - 160
        card_width = 80
        card_height = 112
        total_width = len(hand) * (card_width + 10)
        start_x = (self.screen_width - total_width) // 2

        for i, card in enumerate(hand):
            card_x = start_x + i * (card_width + 10)
            card_rect = pygame.Rect(card_x, hand_y, card_width, card_height)

            # Highlight if selected
            if card.get("card_id") == self.selected_card:
                pygame.draw.rect(self.screen, (255, 200, 50),
                               card_rect.inflate(6, 6), border_radius=6)

            # Card background
            pygame.draw.rect(self.screen, (240, 230, 210), card_rect, border_radius=5)
            pygame.draw.rect(self.screen, (139, 90, 43), card_rect, 2, border_radius=5)

            # Card name
            name = card.get("name", card.get("card_id", "?"))[:10]
            name_surf = pygame.font.Font(None, 16).render(name, True, (50, 40, 30))
            name_rect = name_surf.get_rect(centerx=card_rect.centerx, top=card_rect.top + 5)
            self.screen.blit(name_surf, name_rect)

            # Stats
            attack = card.get("attack", 0)
            health = card.get("health", 0)
            cost = card.get("cost", 0)

            # Cost
            pygame.draw.circle(self.screen, (70, 130, 180),
                             (card_rect.left + 12, card_rect.top + 12), 10)
            cost_surf = pygame.font.Font(None, 18).render(str(cost), True, WHITE)
            self.screen.blit(cost_surf, cost_surf.get_rect(
                center=(card_rect.left + 12, card_rect.top + 12)))

            # Attack/Health
            stats_y = card_rect.bottom - 12
            pygame.draw.circle(self.screen, (200, 60, 60),
                             (card_rect.left + 12, stats_y), 10)
            atk_surf = pygame.font.Font(None, 18).render(str(attack), True, WHITE)
            self.screen.blit(atk_surf, atk_surf.get_rect(
                center=(card_rect.left + 12, stats_y)))

            pygame.draw.circle(self.screen, (60, 160, 60),
                             (card_rect.right - 12, stats_y), 10)
            hp_surf = pygame.font.Font(None, 18).render(str(health), True, WHITE)
            self.screen.blit(hp_surf, hp_surf.get_rect(
                center=(card_rect.right - 12, stats_y)))

    def _draw_turn_info(self):
        """Draw turn information."""
        turn = self.game_state.get("turn", 1)
        is_your_turn = self.game_state.get("is_your_turn", False)
        your_role = self.game_state.get("your_role", "")

        # Turn number
        turn_text = f"Turn {turn}"
        turn_surf = self.font.render(turn_text, True, WHITE)
        self.screen.blit(turn_surf, (20, 50))

        # Current player indicator
        if is_your_turn:
            player_text = "YOUR TURN"
            player_color = GREEN
        else:
            player_text = "OPPONENT'S TURN"
            player_color = RED

        player_surf = self.font.render(player_text, True, player_color)
        self.screen.blit(player_surf, (20, 85))

        # Role
        role_text = f"You are: {your_role.upper()}"
        role_color = RED if your_role == "attacker" else BLUE
        role_surf = self.small_font.render(role_text, True, role_color)
        self.screen.blit(role_surf, (20, 120))

        # End turn button
        if is_your_turn:
            end_turn_rect = pygame.Rect(self.screen_width - 150, 20, 130, 40)
            pygame.draw.rect(self.screen, (150, 100, 50), end_turn_rect, border_radius=8)
            end_surf = self.font.render("End Turn", True, WHITE)
            end_rect = end_surf.get_rect(center=end_turn_rect.center)
            self.screen.blit(end_surf, end_rect)

    def _draw_deck(self):
        """Draw deck indicator."""
        deck_count = self.game_state.get("deck_count", 0)
        can_draw = self.game_state.get("can_draw", False)

        deck_rect = pygame.Rect(self.screen_width - 120, self.screen_height - 180, 100, 140)

        # Draw stacked cards
        for i in range(min(3, deck_count)):
            offset = i * 2
            card_rect = pygame.Rect(deck_rect.x + offset, deck_rect.y - offset, 100, 140)
            color = (80, 60, 40) if can_draw else (50, 50, 50)
            pygame.draw.rect(self.screen, color, card_rect, border_radius=5)
            pygame.draw.rect(self.screen, (60, 40, 20), card_rect, 2, border_radius=5)

        # Card count
        count_surf = self.font.render(str(deck_count), True, WHITE)
        count_rect = count_surf.get_rect(center=deck_rect.center)
        self.screen.blit(count_surf, count_rect)

        # Label
        label = "DECK" if can_draw else "DRAWN"
        label_surf = self.small_font.render(label, True, GRAY)
        label_rect = label_surf.get_rect(centerx=deck_rect.centerx, top=deck_rect.bottom + 5)
        self.screen.blit(label_surf, label_rect)

    def _draw_game_over(self):
        """Draw game over screen."""
        overlay = pygame.Surface((self.screen_width, self.screen_height), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        self.screen.blit(overlay, (0, 0))

        winner = getattr(self, 'winner', 'unknown')
        your_role = self.game_state.get("your_role", "") if self.game_state else ""

        if winner == your_role:
            result_text = "VICTORY!"
            result_color = GREEN
        else:
            result_text = "DEFEAT"
            result_color = RED

        result_surf = self.title_font.render(result_text, True, result_color)
        result_rect = result_surf.get_rect(center=(self.screen_width // 2, self.screen_height // 2 - 50))
        self.screen.blit(result_surf, result_rect)

        hint = self.font.render("Click anywhere to return to lobby", True, WHITE)
        hint_rect = hint.get_rect(center=(self.screen_width // 2, self.screen_height // 2 + 50))
        self.screen.blit(hint, hint_rect)

    def run(self):
        """Main game loop."""
        if not self.connect():
            print("Failed to connect to server!")
            return

        while self.running:
            dt = self.clock.tick(FPS) / 1000.0

            self.handle_events()
            self.update(dt)
            self.draw()

        self.network.disconnect()
        pygame.quit()


def main():
    """Entry point."""
    import argparse
    parser = argparse.ArgumentParser(description="WarMasterMind Client")
    parser.add_argument("--server", default="ws://localhost:8765",
                       help="Server WebSocket URL")
    args = parser.parse_args()

    client = ThinClient(args.server)
    client.run()


if __name__ == "__main__":
    main()
